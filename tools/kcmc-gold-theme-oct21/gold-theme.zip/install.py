#!/usr/bin/env python3
# Compatible with the host's Python 3.6. Only patches the public shell.
from pathlib import Path
import re, hashlib, json, shutil, datetime, os, sys
HERE=Path(__file__).resolve().parent
ROOT=Path('/home/bobsome1/public_html/kcmc-connect')
if '--root' in sys.argv: ROOT=Path(sys.argv[sys.argv.index('--root')+1]).resolve()
APPLY='apply' in sys.argv
manifest=json.loads((HERE/'manifest.json').read_text())
for name,digest in manifest.items():
    if hashlib.sha256((HERE/'payload'/name).read_bytes()).hexdigest()!=digest:
        raise SystemExit('STOP: package verification failed: '+name)
photos=['kcmc-front-porch-official.jpg','kcmc-traditional-sanctuary-20261018.jpg','kcmc-contemporary-gathering-20261018.jpg']
for name in photos:
    if not (ROOT/'assets/visuals'/name).is_file(): raise SystemExit('STOP: matching service photo missing: '+name)
changes={}
for name in ('index.php','index.html'):
    p=ROOT/name
    if not p.is_file(): continue
    text=p.read_text()
    if 'home-cover-photo' not in text: continue
    old=text
    pattern=r'<img\b[^>]*\bclass="home-cover-photo"[^>]*>'
    found=list(re.finditer(pattern,text))
    if len(found)!=1: raise SystemExit('STOP: unexpected hero in '+name)
    hero='<img class="home-cover-photo" src="./assets/visuals/kcmc-gold-hero.webp" alt="KCMC inside a left-facing gold Christian fish on rich blue" loading="eager" decoding="async" fetchpriority="high" width="1672" height="941">'
    text=re.sub(pattern,lambda m:hero,text)
    text,n=re.subn(r'<h1>Welcome Home</h1>','<h1 class="sr-only">Kimberling City Methodist Church</h1>',text)
    # Existing brand link is retained; no new control is introduced.
    text=re.sub(r'(<a\b[^>]*class="welcome-brand"[^>]*>).*?(</a>)',lambda m:m.group(1)+'<img src="./assets/visuals/kcmc-gold-hero.webp" alt="KCMC Connect" width="150" height="76">'+m.group(2),text,flags=re.S)
    # Keep Watch Online inside the app so visitors see all three real services.
    text=re.sub(r'(<div class="welcome-hero-actions">.*?)(<a\b[^>]*>)(Watch Online)',lambda m:m.group(1)+'<a class="btn secondary" href="#watch" data-route="watch">'+m.group(3),text,flags=re.S)
    if 'kcmc-gold-theme.css' not in text:
        if text.count('</head>')!=1: raise SystemExit('STOP: unexpected head in '+name)
        text=text.replace('</head>','<link rel="stylesheet" href="kcmc-gold-theme.css?v=gold-fish-v1">\n</head>')
    dynamic = 'foreach($worshipServices as $service)' in text and 'kcmc_worship_services($kcmc)' in text
    if not dynamic:
        for photo in photos:
            if photo not in text: raise SystemExit('STOP: expected service/photo pairing absent in '+name)
    if text.count('class="service-photo"') != (1 if dynamic else 3):
        raise SystemExit('STOP: unexpected service photo layout in '+name)
    # Changing visual design must not increase links or buttons.
    for tag in ('a','button','form'):
        if len(re.findall(r'<'+tag+r'\b',text))!=len(re.findall(r'<'+tag+r'\b',old)):
            raise SystemExit('STOP: control count changed: '+tag)
    changes[p]=text.encode()
if not changes: raise SystemExit('STOP: public homepage not found.')
for name,rel in [('kcmc-gold-hero.webp','assets/visuals/kcmc-gold-hero.webp'),('kcmc-gold-theme.css','kcmc-gold-theme.css')]:
    changes[ROOT/rel]=(HERE/'payload'/name).read_bytes()
print('Checked: three matching service photos; existing controls retained; no extra buttons.')
if not APPLY:
    print('CHECK PASSED. Run with apply to install.');sys.exit(0)
backup=ROOT.parent.parent/('kcmc-gold-backup-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
backup.mkdir(parents=True)
record={}
for p in changes:
    rel=str(p.relative_to(ROOT));record[rel]=p.exists()
    if p.exists():
        dest=backup/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(str(p),str(dest))
(backup/'files.json').write_text(json.dumps(record))
written=[]
try:
    for p,data in changes.items():
        p.parent.mkdir(parents=True,exist_ok=True)
        tmp=p.with_name(p.name+'.gold-tmp');tmp.write_bytes(data)
        if p.exists():shutil.copymode(str(p),str(tmp))
        else:tmp.chmod(0o644)
        os.replace(str(tmp),str(p));written.append(p)
except Exception:
    for p in reversed(written):
        rel=str(p.relative_to(ROOT))
        if record[rel]:shutil.copy2(str(backup/rel),str(p))
        elif p.exists():p.unlink()
    raise
print('SUCCESS: blue-and-gold public design installed.')
print('Backup: '+str(backup))
print('Open https://bobsome1.com/kcmc-connect/?theme=gold-fish-v1#home')
