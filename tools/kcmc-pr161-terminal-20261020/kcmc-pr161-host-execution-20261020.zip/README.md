# KCMC branding and current-content release candidate — October 20

This review bundle performs no deployment. Verify its published ZIP SHA256,
extract it into a private staging directory outside public_html, and use the
preflight below before a separately authorized installation. Do not extract it
over the live app.

## Public branding scope

Replace exactly `index.php`, `home-welcome.css`, and `sw.js`; add exactly the ten
authentic photographs listed in manifest.json. The requested mission is added
beneath the existing welcome links and the photographs appear below it. Navy,
fish icon, original building/sky, service times, and phone structure stay intact.

The two independently pinned variants are `main` and `livecalendar`. The existing
welcome release already made their index.php identical. Their different
public-presentation.css files remain read-only guards. This package contains no
replacement for that customized stylesheet or any other guard. It contains no
private store, configuration, credentials, account code, or ledger.

```sh
python3 -I -B check-release.py /home/bobsome1/public_html/kcmc-connect
```

Continue only for the expected variant in `before` state. `after` means the exact
bundle is already installed. Unknown, mixed, missing, executable, symbolic-link,
hard-link, changed-guard, or changed-payload states are refused. There is no force
option. The checker writes nothing and verifies staged payloads as well as live
code. Preserve the emitted variant and manifest hash with the release record.

## Installation transaction

The established host transaction mechanism must implement this bounded sequence;
this offline bundle does not contain or authorize a host transaction adapter.

1. Under an exclusive deployment lock, repeat preflight. Take actual private
   backups of the three existing targets; record and verify their hashes, modes,
   ownership and original paths against the selected before tuple. Verify that
   all ten additions are absent. Use a private journal outside public_html.
2. Stage all thirteen `after/` files on the same filesystem. Verify each SHA256
   against manifest.json. Lint staged index.php with the host PHP 8.2+ CLI without
   executing application code. Preserve existing code ownership and 0644/0664
   modes; give added public images the same reviewed ownership and 0644 mode.
3. Recheck the full before tuple, guard hashes, original metadata, and stage
   hashes immediately before replacements. Install the ten images first, then
   home-welcome.css, index.php, and sw.js last using atomic file replacements.
   Record each outcome in the durable private journal.
4. Re-run the exact preflight and require the same variant in `after` state.
   Verify the public home at phone and desktop widths, mission, all ten pictures,
   native expansion, original sky/building, Visit/Watch/Events/Prayer/Family links,
   and a refreshed service worker. Capture the actual resulting public responses.

If a replacement or acceptance check fails, stop. Under the same lock, accept
only each target's recorded before or after image; refuse unknown concurrent
edits. Restore index.php and sw.js from actual backups before removing any new
photo. Restore home-welcome.css, then remove a new photo only if its bytes match
the exact installed image and no retained consumer references it. Preserve
metadata. Verify the original variant in `before` state. `before/` holds reference
bytes; actual host backups are authoritative for rollback. Do not restore an
entire app directory or overwrite any live content store.

Server rollback does not immediately refresh every already installed device.
Check online appearance and a fresh worker update before describing cache state.

## Separate current-content publication

`content-publication/` contains a separate, hash-verified record-level publisher
with check/apply/rollback commands. Follow its README after reviewing its exact
live action list and receiving publication authorization. Its four bulletin
fields and specific event/announcement changes are independent of the thirteen
branding files. Do not copy repository data/content.json to the live host.

The content recipe accepts only October 20–25 local dates, skips expired records,
preserves staff edits or refuses conflicts, and records private actual-byte
backups. It performs no message sending. Keep its receipts/backups outside the
public tree and outside source control.
