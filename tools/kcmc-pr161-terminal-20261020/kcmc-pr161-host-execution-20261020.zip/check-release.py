#!/usr/bin/env python3
"""Read-only exact bundle preflight. No network, apply, force or configuration access."""
import hashlib,json,os,stat,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
PIN='84ed0526d049b04d066d0498efc96b098eb05f54a267600b6aa0256b821967ed'
def need(ok,message):
    if not ok: raise RuntimeError(message)
def read(root,name,missing=False):
    p=root/name
    for parent in p.parents:
        need(parent.is_dir() and not parent.is_symlink(),'Unsafe directory: '+str(parent))
    if not p.exists() and not p.is_symlink():
        need(missing,'Missing file: '+name); return None
    info=p.lstat()
    need(stat.S_ISREG(info.st_mode) and info.st_nlink==1 and
         stat.S_IMODE(info.st_mode) in (0o644,0o664),'Unsafe file metadata: '+name)
    need(info.st_size<=16*1024*1024,'Oversized file: '+name)
    fd=os.open(str(p),os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
    with os.fdopen(fd,'rb') as f:
        actual=os.fstat(f.fileno())
        need((info.st_dev,info.st_ino)==(actual.st_dev,actual.st_ino),'File changed: '+name)
        data=f.read(16*1024*1024+1)
    final=p.lstat()
    fields=lambda x:(x.st_dev,x.st_ino,x.st_size,x.st_mtime_ns)
    need(fields(info)==fields(final) and len(data)==info.st_size,'File changed: '+name)
    return {'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
def inspect(root):
    raw=(HERE/'manifest.json').read_bytes()
    need(hashlib.sha256(raw).hexdigest()==PIN,'Release manifest changed')
    manifest=json.loads(raw)
    for name,pin in manifest['payloads'].items():
        need(read(HERE,name)==pin,'Staged release payload changed: '+name)
    matches=[]
    for variant,bundle in manifest['variants'].items():
        if all(read(root,n)==pin for n,pin in bundle['guards'].items()):
            for phase in ['before','after']:
                if all(read(root,n,True)==pin for n,pin in bundle[phase].items()):
                    matches.append((variant,phase))
    need(len(matches)==1,'Unknown, mixed or incomplete public bundle; installation refused')
    return matches[0]
if __name__=='__main__':
    try:
        need(len(sys.argv)==2,'Usage: python3 -I -B check-release.py /home/bobsome1/public_html/kcmc-connect')
        variant,phase=inspect(Path(os.path.abspath(sys.argv[1])))
        print('CHECK',variant,phase,'(read only; no installation performed)')
    except (OSError,RuntimeError,ValueError) as exc:
        print('REFUSED:',exc,file=sys.stderr);sys.exit(1)
