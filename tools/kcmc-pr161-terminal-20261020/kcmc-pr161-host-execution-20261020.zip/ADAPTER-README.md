# KCMC PR161 host execution supplement

This supplement implements the already reviewed thirteen-file branding scope.
It is ready for operator review; it has not run on the hosting account. The
original review ZIP and every original ZIP entry are unchanged. The execution
package adds this document, `install-brand.py`, and an acceptance report beside
the original files. It is independent of the separate content publisher.

## Exact identity and scope

- Reviewed PR: `https://github.com/bobhay75/Kcmc-connect/pull/161`
- Reviewed source head: `cac1420a905bba78a4a54651c69a8e77b57b2450`
- Original review ZIP SHA256:
  `8f36ee23d5db9bbe811e21fd915948baf0ab7fa88cd3961b17bb1cb9f807ef04`
- Unchanged release manifest SHA256:
  `84ed0526d049b04d066d0498efc96b098eb05f54a267600b6aa0256b821967ed`
- Fixed target: `/home/bobsome1/public_html/kcmc-connect`
- Fixed account: UID `2162`, GID `2147`; do not use root or another account.
- Private transaction root: `/home/bobsome1/kcmc-brand-oct20-backups`
- Expected installed variant: `livecalendar`.

Only `index.php`, `home-welcome.css`, `sw.js`, and the ten exact manifest JPGs are
written in the app. The original building picture and customized
`public-presentation.css` are read-only guards. No application configuration,
private record, timeclock, mail, account, or content store is read or changed by
this adapter. Its own private journals and actual-byte backups stay outside
`public_html`.

## Private staging and checks

Verify the execution ZIP against its separately supplied SHA256 before extraction.
Use cPanel File Manager to extract it into a new private folder such as
`/home/bobsome1/kcmc-pr161-stage-20261020`, never over the live app. The staging
folder must be outside `public_html`, owned by the hosting account, with mode
0700. Original bundle files must remain regular 0644 or 0664 files; do not apply
permission changes to the live app to make a refusal pass.

From that private staging folder in cPanel Terminal:

```sh
python3 -I -B check-release.py /home/bobsome1/public_html/kcmc-connect
python3 -I -B install-brand.py check
python3 -I -B content-publication/publish.py check
```

The first check must print `CHECK livecalendar before`. The adapter must report
`variant: livecalendar`, `state: before`, and `writes_performed: false`. All
payload hashes, eleven unchanged public guards, target states, file metadata,
and existing transaction journals are checked. Unknown/mixed files, links,
executables, different ownership, changed payloads, and incomplete sessions are
refused. The check creates no directory, lock, backup, or app file.

The separate content check must be reviewed for its exact action list and live
SHA256. `ready` permits the reviewed content operation; `already_current` needs
no operation. A conflict requires reviewing that live record, not rewriting the
fixture or replacing the whole content store. The content window is October
20–25, 2026, Central time.

## Authorized branding installation

After the authorized host checks pass:

```sh
python3 -I -B install-brand.py apply --expected-variant livecalendar
python3 -I -B check-release.py /home/bobsome1/public_html/kcmc-connect
python3 -I -B install-brand.py check
```

The adapter uses an exclusive private deployment lock, records original bytes,
modes and ownership, verifies actual backups, and stages files on the same
filesystem. It finds a PHP 8.2+ CLI and lints staged `index.php` without executing
the application. It verifies full file leases and all guards immediately before
each atomic replacement. Order: ten photographs, CSS, homepage, service worker.
The successful result prints the private session path and exact rollback command.
The independent checker must then say `CHECK livecalendar after`.

Verify the actual public page at phone and desktop widths: the original building
and natural sky, navy/gold branding, left-facing fish, service times, mission,
all ten photographs, three featured photographs and native expansion, and the
Visit/Watch/Events/Prayer/Family routes. Verify the online page and an updated
service worker before making cache claims. A server transaction alone does not
prove browser acceptance.

## Separate content publication

Use the exact SHA256 from the successful live content check:

```sh
python3 -I -B content-publication/publish.py apply --expected-sha256 SHA256_FROM_CHECK
python3 -I -B content-publication/publish.py check
```

Substitute the actual hash, not the literal placeholder. The final content check
must say `already_current`. Verify the October 20–25 bulletin, October 22 meeting
at 1:30 PM, and recurring Sunday Friends of Faith class at 10:20 AM. Preserve the
authentic 5:17 PM time. This tool has its own private receipt and rollback; see
the unchanged `content-publication/README.md`. Never copy source
`data/content.json` to production.

## Failure and recovery

Immediate caught installation failure attempts exact rollback in the same
process and lock. It can remove only the exact photographs introduced by that
transaction, while their recorded inodes/leases and all scope guards remain
unchanged. Any unknown concurrent edit blocks automatic recovery and is
preserved. Actual backups are authoritative; reference `before/` files are not
used as host backups.

For an interrupted process or later acceptance failure, run the exact printed
rollback command, using its session basename:

```sh
python3 -I -B install-brand.py rollback --session EXACT_PRINTED_SESSION_BASENAME
```

**Manual rollback is deliberately conservative.** It restores the three existing
code files from verified actual backups, but retains any new photographs because
another public page or content record may have begun referencing them. It reports
`recovered_code_with_photos_retained`, the retained filenames, and
`exact_original_bundle: false`. That result does not match the original thirteen-
file `before` tuple and must not be described as an exact full rollback. A later
public-reference review is required before photo cleanup; this adapter provides
no cleanup bypass or force option. Unfinished or retained-photo sessions block a
new installation until reviewed.

An interruption during preparation before live writes can be retired by the same
exact-session rollback command only if the complete original live tuple and any
recorded leases remain unchanged. Even a session interrupted before its first
journal is handled without restoring or deleting a live file. A retired receipt
cannot roll back a later installation.

Server rollback does not immediately update every installed browser cache. Keep
all private sessions and receipts for review. No release should be called live
until its actual host and public browser checks succeed.

## Validation and limits

See `ADAPTER-ACCEPTANCE.json` for the actual local test outcome. Tests use only
disposable synthetic app trees and import-time monkeypatching; production has no
target/account/PHP/force override flag. The suite covers both independent variants,
all thirteen replacement failure and abrupt-loss boundaries, interrupted recovery,
unknown concurrent edits, actual-backup corruption, unsafe paths/modes, no-write
refusals, PHP lint refusal, conservative retained-photo recovery, and journal
retirement. Python 3.6 syntax is checked. Local PHP lint uses PHP 8.3; host lint
must still succeed with the actual PHP 8.2+ executable.

Filesystem locks are cooperative. Full leases detect unexpected changes but do
not grant exclusive control over other independently running host tools. Keep
other code deployments paused throughout installation and acceptance.
