#!/usr/bin/env python3
"""Synthetic disposable fixtures only; no production target or account access."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import tempfile
import unittest
import zipfile

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / 'Kcmc-branding'
ZIP = ROOT.parent / 'kcmc-brand-content-20261020-review.zip'
PHP = '/tmp/kcmc-php-runtime/bin/php'
BASE = 'ca0d6197b4be7339fd5937f216202a7e5fbdd13d'
PREFIX = 'KCMC-Connect-Phase6-Recreated/'


class PowerLoss(BaseException):
    pass


class Fixture(object):
    def __init__(self, variant='livecalendar'):
        self.temp = tempfile.TemporaryDirectory(prefix='kcmc-brand-transaction-test-')
        self.root = Path(self.temp.name)
        self.here, self.app = self.root / 'review', self.root / 'app'
        self.here.mkdir()
        self.app.mkdir()
        with zipfile.ZipFile(ZIP) as archive:
            archive.extractall(self.here)
        self.variant = variant
        self.load()
        self.reviewed = self.m.manifest()
        scope = self.reviewed['variants'][variant]
        for name in self.m.MODIFIED:
            (self.app / name).write_bytes((self.here / 'before' / name).read_bytes())
        for name in self.m.GUARDS:
            path = self.app / name
            path.parent.mkdir(parents=True, exist_ok=True)
            gitpath = PREFIX + name
            if variant == 'livecalendar' and name == 'public-presentation.css':
                gitpath = 'tools/kcmc-follow-up-oct18/evidence/public/livecalendar/' + name
            raw = subprocess.check_output(['git', 'show', BASE + ':' + gitpath], cwd=str(REPO))
            self.assert_pin(raw, scope['guards'][name])
            path.write_bytes(raw)
        (self.app / 'home-welcome.css').chmod(0o664)
        (self.app / 'data').mkdir()
        self.sentinel = self.app / 'data' / 'do-not-touch.txt'
        self.sentinel.write_bytes(b'unrelated private synthetic data must remain untouched\n')
        self.initial = self.state()

    def load(self):
        spec = importlib.util.spec_from_file_location('brand_adapter', ROOT / 'install-brand.py')
        self.m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.m)
        # Test injection is only import-time monkeypatching; no such CLI exists.
        self.m.HERE, self.m.APP = self.here, self.app
        self.m.BACKUPS = self.root / 'backups'
        self.m.UID, self.m.GID = os.getuid(), os.getgid()
        self.m.PHP_CANDIDATES = (PHP,)
        return self.m

    @staticmethod
    def assert_pin(raw, pin):
        assert len(raw) == pin['bytes'] and hashlib.sha256(raw).hexdigest() == pin['sha256']

    def state(self):
        result = {}
        for path in self.app.rglob('*'):
            if path.is_file():
                s = path.stat()
                result[str(path.relative_to(self.app))] = (path.read_bytes(), stat.S_IMODE(s.st_mode), s.st_uid, s.st_gid)
        return result

    def apply(self):
        self.m.caller()
        return self.m.apply(self.m.manifest(), self.variant)

    def session(self):
        return next(path for path in self.m.BACKUPS.iterdir() if path.is_dir())

    def close(self):
        self.temp.cleanup()


class InstallTests(unittest.TestCase):
    def fixture(self, variant='livecalendar'):
        value = Fixture(variant)
        self.addCleanup(value.close)
        return value

    def assert_before(self, f):
        self.assertEqual(f.state(), f.initial)
        variant, phase, unused, guards = f.m.inspect(f.reviewed)
        self.assertEqual((variant, phase), (f.variant, 'before'))

    def assert_code_restored(self, f):
        actual = f.state()
        for name, original in f.initial.items():
            self.assertEqual(actual[name], original, name)
        for name in f.m.ADDED:
            if name in actual:
                f.assert_pin(actual[name][0], f.reviewed['variants'][f.variant]['after'][name])
                self.assertEqual(actual[name][1], 0o644)

    def fixture_only_cleanup_after_reference_review(self, f):
        # This models a later independent reference review in a disposable test
        # fixture. There is deliberately no production cleanup/force flag.
        for name in f.m.ADDED:
            target = f.app / name
            if target.exists():
                target.unlink()
        f.m.rollback(f.reviewed, f.session().name)
        self.assert_before(f)

    def test_exact_apply_and_actual_backup_both_variants(self):
        for variant in ('main', 'livecalendar'):
            with self.subTest(variant=variant):
                f = self.fixture(variant)
                old_guards = {n: f.m.read(f.app / n)[1] for n in f.m.GUARDS}
                result = f.apply()
                self.assertEqual(result['result'], 'installed')
                self.assertEqual(f.m.inspect(f.reviewed)[:2], (variant, 'after'))
                self.assertEqual(result['files'], list(f.m.ORDER))
                self.assertEqual(len(set(f.state()) - set(f.initial)), 10)
                self.assertEqual(f.sentinel.read_bytes(), f.initial['data/do-not-touch.txt'][0])
                self.assertEqual({n: f.m.read(f.app / n)[1] for n in f.m.GUARDS}, old_guards)
                record = f.m.read_journal(f.session())
                self.assertEqual(record['state'], 'applied')
                for name in f.m.MODIFIED:
                    backup = f.m.backup_path(f.session(), name)
                    self.assertEqual(backup.read_bytes(), f.initial[name][0])
                    self.assertEqual(stat.S_IMODE(backup.stat().st_mode), 0o600)
                    self.assertEqual((f.app / name).stat().st_mode & 0o777, f.initial[name][1])
                for name in f.m.ADDED:
                    self.assertEqual((f.app / name).stat().st_mode & 0o777, 0o644)
                journal_before = (f.session() / 'journal.json').read_bytes()
                self.assertEqual(f.apply()['result'], 'already_installed')
                self.assertEqual((f.session() / 'journal.json').read_bytes(), journal_before)
                result = f.m.rollback(f.reviewed, f.session().name)
                self.assertEqual(result['result'], 'recovered_code_with_photos_retained')
                self.assertFalse(result['exact_original_bundle'])
                self.assertEqual(len(result['retained_images']), 10)
                self.assert_code_restored(f)
                self.fixture_only_cleanup_after_reference_review(f)

    def test_failed_live_preflights_create_nothing(self):
        mutations = {
            'wrong_target_bytes': lambda f: (f.app / 'index.php').write_bytes(b'unknown edit'),
            'wrong_guard_bytes': lambda f: (f.app / 'public-presentation.css').write_bytes(b'custom changed'),
            'premature_new_image': lambda f: (f.app / f.m.ADDED[0]).write_bytes(b'unknown image'),
            'executable_target': lambda f: (f.app / 'index.php').chmod(0o755),
            'hard_link_target': lambda f: os.link(str(f.app / 'index.php'), str(f.root / 'linked-index.php')),
            'symlink_target': self.make_target_symlink,
            'symlink_parent': self.make_parent_symlink,
        }
        for name, mutate in mutations.items():
            with self.subTest(case=name):
                f = self.fixture()
                mutate(f)
                snapshot = f.state()
                with self.assertRaises((OSError, f.m.Refusal)):
                    f.apply()
                self.assertEqual(f.state(), snapshot)
                self.assertFalse(f.m.BACKUPS.exists())

    @staticmethod
    def make_target_symlink(f):
        target = f.app / 'index.php'
        outside = f.root / 'outside-index.php'
        target.rename(outside)
        target.symlink_to(outside)

    @staticmethod
    def make_parent_symlink(f):
        target = f.app / 'assets' / 'visuals'
        outside = f.root / 'outside-visuals'
        target.rename(outside)
        target.symlink_to(outside, target_is_directory=True)

    def test_changed_bundle_payload_and_manifest_refused_without_writes(self):
        for name in ('manifest.json', 'after/index.php',
                     'after/assets/visuals/kcmc-contemporary-after-service-20261018.jpg',
                     'content-publication/publish.py'):
            with self.subTest(path=name):
                f = self.fixture()
                path = f.here / name
                path.write_bytes(path.read_bytes() + b'changed')
                with self.assertRaises(f.m.Refusal):
                    f.apply()
                self.assert_before(f)
                self.assertFalse(f.m.BACKUPS.exists())

    def test_unexpected_variant_no_writes(self):
        f = self.fixture()
        with self.assertRaises(f.m.Refusal):
            f.m.apply(f.reviewed, 'main')
        self.assert_before(f)
        self.assertFalse(f.m.BACKUPS.exists())

    def test_failure_after_each_of_thirteen_replacements_rolls_back(self):
        for boundary in range(1, 14):
            with self.subTest(boundary=boundary):
                f = self.fixture()
                original = f.m.replace
                count = [0]
                def injected(source, target, source_info, target_info):
                    original(source, target, source_info, target_info)
                    if f.app in Path(target).parents:
                        count[0] += 1
                        if count[0] == boundary:
                            raise RuntimeError('synthetic failure after atomic live replacement')
                f.m.replace = injected
                with self.assertRaisesRegex(f.m.Refusal, 'original bundle was restored'):
                    f.apply()
                self.assert_before(f)
                self.assertEqual(f.m.read_journal(f.session())['state'], 'rolled_back')

    def test_process_loss_after_each_replacement_can_resume_rollback(self):
        for boundary in range(1, 14):
            with self.subTest(boundary=boundary):
                f = self.fixture()
                original = f.m.replace
                count = [0]
                def killed(source, target, source_info, target_info):
                    original(source, target, source_info, target_info)
                    if f.app in Path(target).parents:
                        count[0] += 1
                        if count[0] == boundary:
                            raise PowerLoss('synthetic abrupt process loss')
                f.m.replace = killed
                with self.assertRaises(PowerLoss):
                    f.apply()
                session_name = f.session().name
                f.load()
                if boundary == 13:
                    # Complete after bytes are insufficient if the durable
                    # installation journal was interrupted before completion.
                    with self.assertRaisesRegex(f.m.Refusal, 'Unfinished transaction'):
                        f.apply()
                result = f.m.rollback(f.m.manifest(), session_name)
                self.assertEqual(result['result'], 'recovered_code_with_photos_retained')
                self.assertEqual(len(result['retained_images']), min(boundary, 10))
                self.assert_code_restored(f)

    def test_rollback_process_loss_after_each_restore_can_resume(self):
        for boundary in (1, 2, 3):
            with self.subTest(boundary=boundary):
                f = self.fixture()
                f.apply()
                session_name = f.session().name
                original = f.m.replace
                count = [0]
                def killed(source, target, source_info, target_info):
                    original(source, target, source_info, target_info)
                    if f.app in Path(target).parents:
                        count[0] += 1
                        if count[0] == boundary:
                            raise PowerLoss('synthetic rollback process loss')
                f.m.replace = killed
                with self.assertRaises(PowerLoss):
                    f.m.rollback(f.reviewed, session_name)
                f.load()
                result = f.m.rollback(f.m.manifest(), session_name)
                self.assertEqual(result['result'], 'recovered_code_with_photos_retained')
                self.assert_code_restored(f)

    def test_rollback_process_loss_after_image_removal_can_resume(self):
        f = self.fixture()
        f.apply()
        session_name = f.session().name
        original = f.m.os.unlink
        count = [0]
        def killed(path, *args, **kwargs):
            original(path, *args, **kwargs)
            if str(path).endswith('.jpg'):
                count[0] += 1
                if count[0] == 4:
                    raise PowerLoss('synthetic interruption after image removal')
        f.m.os.unlink = killed
        try:
            with self.assertRaises(PowerLoss):
                with f.m.deployment_lock():
                    f.m.rollback_locked(f.reviewed, f.session(), cleanup_photos=True)
        finally:
            f.m.os.unlink = original
        f.load()
        result = f.m.rollback(f.m.manifest(), session_name)
        self.assertEqual(result['result'], 'recovered_code_with_photos_retained')
        self.assertEqual(len(result['retained_images']), 6)
        self.assert_code_restored(f)

    def test_intervening_target_or_guard_or_backup_edit_blocks_all_rollback(self):
        for changed in ('index.php', 'sw.js', 'public-presentation.css', 'backup'):
            with self.subTest(changed=changed):
                f = self.fixture()
                f.apply()
                target = f.m.backup_path(f.session(), 'index.php') if changed == 'backup' else f.app / changed
                target.write_bytes(target.read_bytes() + b'\nConcurrent edit\n')
                snapshot = f.state()
                with self.assertRaises(f.m.Refusal):
                    f.m.rollback(f.reviewed, f.session().name)
                self.assertEqual(f.state(), snapshot)

    def test_metadata_change_blocks_rollback(self):
        f = self.fixture()
        f.apply()
        (f.app / 'index.php').chmod(0o664)
        snapshot = f.state()
        with self.assertRaises(f.m.Refusal):
            f.m.rollback(f.reviewed, f.session().name)
        self.assertEqual(f.state(), snapshot)

    def test_exact_lease_prevents_overwriting_concurrent_target(self):
        f = self.fixture()
        original = f.m.replace
        expected_bytes = b'New staff edit must survive\n'
        def inject(source, target, source_info, target_info):
            if Path(target) == f.app / 'home-welcome.css':
                Path(target).write_bytes(expected_bytes)
            original(source, target, source_info, target_info)
        f.m.replace = inject
        with self.assertRaisesRegex(f.m.Refusal, 'Conditional rollback requires review'):
            f.apply()
        self.assertEqual((f.app / 'home-welcome.css').read_bytes(), expected_bytes)
        self.assertEqual((f.app / 'index.php').read_bytes(), f.initial['index.php'][0])
        self.assertEqual((f.app / 'sw.js').read_bytes(), f.initial['sw.js'][0])

    def test_lint_failure_keeps_original_app(self):
        f = self.fixture()
        original = f.m.subprocess.run
        def bad_lint(args, **kwargs):
            if '-l' in args:
                return subprocess.CompletedProcess(args, 1, stdout=b'', stderr=b'synthetic lint failure')
            return original(args, **kwargs)
        f.m.subprocess.run = bad_lint
        try:
            with self.assertRaisesRegex(f.m.Refusal, 'original bundle was restored'):
                f.apply()
        finally:
            f.m.subprocess.run = original
        self.assert_before(f)

    def test_unfinished_before_write_blocks_apply_until_explicit_rollback(self):
        f = self.fixture()
        original = f.m.journal
        def kill_at_install(session, record):
            original(session, record)
            if record['state'] == 'installing':
                raise PowerLoss('synthetic loss before first replacement')
        f.m.journal = kill_at_install
        with self.assertRaises(PowerLoss):
            f.apply()
        self.assert_before(f)
        session_name = f.session().name
        f.load()
        with self.assertRaisesRegex(f.m.Refusal, 'Unfinished transaction'):
            f.apply()
        self.assert_before(f)
        f.m.rollback(f.reviewed, session_name)
        self.assertEqual(f.apply()['result'], 'installed')

    def test_incomplete_actual_backup_sessions_retire_without_live_write(self):
        for boundary in (1, 2, 3):
            with self.subTest(boundary=boundary):
                f = self.fixture()
                original = f.m.write_new
                count = [0]
                def killed(path, raw, mode=0o600):
                    info = original(path, raw, mode)
                    if Path(path).name.startswith('before-'):
                        count[0] += 1
                        if count[0] == boundary:
                            raise PowerLoss('synthetic interruption during actual backup')
                    return info
                f.m.write_new = killed
                with self.assertRaises(PowerLoss):
                    f.apply()
                self.assert_before(f)
                session_name = f.session().name
                f.load()
                result = f.m.rollback(f.reviewed, session_name)
                self.assertEqual(result['result'], 'unstarted_session_retired')
                self.assertFalse(result['live_writes_performed'])
                self.assert_before(f)
                self.assertEqual(f.apply()['result'], 'installed')

    def test_loss_before_initial_journal_can_retire_only_full_before_state(self):
        f = self.fixture()
        original = f.m.journal
        def killed(session, record):
            if record['state'] == 'preparing':
                raise PowerLoss('synthetic loss immediately before initial journal')
            return original(session, record)
        f.m.journal = killed
        with self.assertRaises(PowerLoss):
            f.apply()
        self.assert_before(f)
        session_name = f.session().name
        f.load()
        with self.assertRaisesRegex(f.m.Refusal, 'Unstarted session'):
            f.apply()
        (f.app / 'index.php').write_bytes(b'changed after preparation interruption')
        snapshot = f.state()
        with self.assertRaises(f.m.Refusal):
            f.m.rollback(f.reviewed, session_name)
        self.assertEqual(f.state(), snapshot)
        (f.app / 'index.php').write_bytes(f.initial['index.php'][0])
        result = f.m.rollback(f.reviewed, session_name)
        self.assertEqual(result['result'], 'unstarted_session_retired')
        self.assert_before(f)

    def test_retired_receipt_cannot_rollback_later_installation(self):
        f = self.fixture()
        f.apply()
        old_session = f.session().name
        f.m.rollback(f.reviewed, old_session)
        self.fixture_only_cleanup_after_reference_review(f)
        self.assertEqual(f.m.rollback(f.reviewed, old_session)['result'], 'already_rolled_back')
        f.apply()
        snapshot = f.state()
        with self.assertRaisesRegex(f.m.Refusal, 'later installation'):
            f.m.rollback(f.reviewed, old_session)
        self.assertEqual(f.state(), snapshot)

    def test_later_public_reference_survives_conservative_manual_rollback(self):
        f = self.fixture()
        f.apply()
        new_consumer = f.app / 'new-public-page.html'
        raw = ('<img src="' + f.m.ADDED[0] + '">').encode('ascii')
        new_consumer.write_bytes(raw)
        result = f.m.rollback(f.reviewed, f.session().name)
        self.assertEqual(result['result'], 'recovered_code_with_photos_retained')
        self.assertEqual(new_consumer.read_bytes(), raw)
        self.assertTrue((f.app / f.m.ADDED[0]).exists())
        self.assert_code_restored(f)
        with self.assertRaisesRegex(f.m.Refusal, 'retained photos'):
            f.m.existing_journals_clear()

    def test_rollback_rejects_arbitrary_session_path(self):
        f = self.fixture()
        for value in ('../../other', '/tmp/other', 'release-invalid', ''):
            with self.subTest(value=value), self.assertRaises(f.m.Refusal):
                f.m.rollback(f.reviewed, value)
        self.assertFalse(f.m.BACKUPS.exists())

    def test_python36_syntax_and_no_production_override_flags(self):
        import ast
        source = (ROOT / 'install-brand.py').read_text()
        ast.parse(source, feature_version=(3, 6))
        self.assertNotIn("add_argument('--target'", source)
        self.assertNotIn("add_argument('--force'", source)
        self.assertNotIn("add_argument('--uid'", source)
        self.assertNotIn("add_argument('--php'", source)


if __name__ == '__main__':
    unittest.main(verbosity=2)
