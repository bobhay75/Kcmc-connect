'use strict';
(() => {
const $=id=>document.getElementById(id);
const central=new Intl.DateTimeFormat('en-CA',{timeZone:'America/Chicago',year:'numeric',month:'2-digit',day:'2-digit'});
const parts=Object.fromEntries(central.formatToParts(new Date()).map(p=>[p.type,p.value]));
const today=parts.year+'-'+parts.month+'-'+parts.day;
let selected=today,month=new Date(Number(parts.year),Number(parts.month)-1,1),events=[];
const key=d=>[d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-');
const popup=document.createElement('dialog');popup.className='day-popup';popup.setAttribute('aria-labelledby','popupTitle');
const popupClose=document.createElement('button');popupClose.type='button';popupClose.textContent='Close';popupClose.className='popup-close';popupClose.addEventListener('click',()=>popup.close());
const popupTitle=document.createElement('h2');popupTitle.id='popupTitle';const popupBody=document.createElement('div');popup.append(popupClose,popupTitle,popupBody);document.body.append(popup);
popup.addEventListener('click',event=>{if(event.target===popup){const r=popup.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)popup.close();}});
popup.addEventListener('close',()=>{document.querySelector('button.day[aria-pressed="true"]')?.focus();});
function card(e){const box=document.createElement('article');box.className='event';const title=document.createElement('h3');title.textContent=e.title;box.append(title);if(e.time){const t=document.createElement('p');t.className='event-time';t.textContent=e.time;box.append(t);}if(e.image){const im=document.createElement('img');im.src=e.image;im.alt=e.alt||e.title;im.loading='lazy';im.addEventListener('error',()=>im.remove());box.append(im);}const p=document.createElement('p');p.textContent=e.body||'Contact the church office for details.';box.append(p);return box;}
function show(openPopup=false){const d=new Date(selected+'T12:00:00');const title=d.toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric',year:'numeric'});$('selected').textContent=title;const list=events.filter(e=>e.date===selected);$('events').replaceChildren(...list.map(card));if(!list.length){const p=document.createElement('p');p.textContent='No published events for this date.';$('events').append(p);}if(openPopup){popupTitle.textContent=title;popupBody.replaceChildren(...list.map(card));if(!list.length){const p=document.createElement('p');p.textContent='No published events for this date.';popupBody.append(p);}popup.showModal();}}
function render(){
$('month').textContent=month.toLocaleDateString('en-US',{month:'long',year:'numeric'});$('days').replaceChildren();
for(const name of ['Sun','Mon','Tue','Wed','Thu','Fri','Sat']){const el=document.createElement('div');el.className='weekday';el.textContent=name;$('days').append(el);}
for(let i=0;i<month.getDay();i++){$('days').append(document.createElement('div'));}
const last=new Date(month.getFullYear(),month.getMonth()+1,0).getDate();
for(let day=1;day<=last;day++){
const d=new Date(month.getFullYear(),month.getMonth(),day),k=key(d),list=events.filter(e=>e.date===k);const btn=document.createElement('button');btn.type='button';btn.className='day'+(list.length?' has-events':'')+(k===today?' today':'');btn.setAttribute('aria-pressed',String(k===selected));btn.setAttribute('aria-haspopup','dialog');btn.setAttribute('aria-label',d.toLocaleDateString('en-US',{month:'long',day:'numeric',year:'numeric'})+(list.length?': '+list.map(e=>(e.time?e.time+' — ':'')+e.title).join('; '):': No published events'));if(k===today)btn.setAttribute('aria-current','date');const number=document.createElement('span');number.className='day-number';number.textContent=day;btn.append(number);
for(const event of list){const label=document.createElement('span');label.className='day-event';if(event.time){const time=document.createElement('span');time.className='day-event-time';time.textContent=event.time;label.append(time);}const name=document.createElement('span');name.textContent=event.title;label.append(name);btn.append(label);}
btn.addEventListener('click',()=>{selected=k;render();show(true);});$('days').append(btn);
}
}
$('prev').addEventListener('click',()=>{month=new Date(month.getFullYear(),month.getMonth()-1,1);selected=key(month);render();show();});
$('next').addEventListener('click',()=>{month=new Date(month.getFullYear(),month.getMonth()+1,1);selected=key(month);render();show();});
$('today').addEventListener('click',()=>{selected=today;month=new Date(today+'T12:00:00');month.setDate(1);render();show();});
fetch('events.php?event_scope=calendar',{cache:'no-store',credentials:'omit'}).then(r=>{if(!r.ok)throw Error();return r.text();}).then(html=>{
const doc=new DOMParser().parseFromString(html,'text/html');const rows=[...doc.querySelectorAll('article.eventx')];if(!doc.querySelector('main#events'))throw Error();events=rows.map(row=>{const c=row.cloneNode(true);const title=c.querySelector('h2')?.textContent.trim()||'Church gathering';const timeNode=c.querySelector('time[datetime]');const date=row.getAttribute('data-calendar-date')||timeNode?.getAttribute('datetime')||'';const small=c.querySelector('small');const time=row.getAttribute('data-calendar-time')||(small?small.textContent.replace(timeNode?.textContent||'','').replace(/^\s*[•·]\s*/,'').trim():'');
const imageNode=c.querySelector('img');let image='';if(imageNode){try{const u=new URL(imageNode.getAttribute('src'),new URL('events.php',location.href));if(u.origin===location.origin&&u.pathname.includes('/assets/visuals/'))image=u.href;}catch{}}const alt=imageNode?.getAttribute('alt')||'';
c.querySelectorAll('summary,img,a,button,script,style,small').forEach(x=>x.remove());const body=[...c.querySelectorAll('p')].map(x=>x.textContent.trim()).filter(x=>x&&!/^Listed in .*weekly calendar\.?$/i.test(x)).join('\n\n');return {title,time,image,alt,date:/^\d{4}-\d{2}-\d{2}$/.test(date)?date:'',body};});
const undated=events.filter(e=>!e.date);$('undated').hidden=!undated.length;$('undatedEvents').replaceChildren(...undated.map(card));$('status').textContent='Select a day to open its event details. Times are Central.';$('calendar').hidden=false;render();show();
}).catch(()=>{$('status').replaceChildren(document.createTextNode('The calendar could not load. '));const a=document.createElement('a');a.href='events.php?event_scope=calendar';a.textContent='Open the published event list';$('status').append(a);});
})();
