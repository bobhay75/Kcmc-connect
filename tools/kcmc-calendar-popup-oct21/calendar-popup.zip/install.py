from pathlib import Path
import hashlib,json,datetime,shutil,os,sys,re
HERE=Path(__file__).resolve().parent
ROOT=Path('/home/bobsome1/public_html/kcmc-connect')
if '--root' in sys.argv:ROOT=Path(sys.argv[sys.argv.index('--root')+1])
manifest=json.loads((HERE/'manifest.json').read_text())
for name,h in manifest.items():
 if hashlib.sha256((HERE/'payload'/name).read_bytes()).hexdigest()!=h:raise SystemExit('STOP: Package verification failed.')
for name in ('church-calendar.html','church-calendar.js'):
 p=ROOT/name
 if not p.is_file():raise SystemExit('STOP: Existing calendar file missing: '+name)
if 'id="days"' not in (ROOT/'church-calendar.html').read_text():raise SystemExit('STOP: Calendar differs; nothing changed.')
eventsPage=ROOT/'events.php'
eventsSource=eventsPage.read_text()
old='<article class="eventx">'
new='<article class="eventx" data-calendar-date="<?=kcmc_h((string)($event[\'date\'] ?? \'\'))?>" data-calendar-time="<?=kcmc_h($timeLabel)?>">'
if 'data-calendar-date' not in eventsSource:
 if eventsSource.count(old)!=1:raise SystemExit('STOP: Events template differs; nothing changed.')
 eventsSource=eventsSource.replace(old,new)
changes={name:(HERE/'payload'/name).read_bytes() for name in ('church-calendar.html','church-calendar.js')}
css=ROOT/'app-theme.css'
if not css.is_file() or not (ROOT/'assets/visuals/kcmc-gold-hero.webp').is_file():raise SystemExit('STOP: Shared theme or approved brand image missing.')
cssText=css.read_text()
cssText=re.sub(r'/\* KCMC_SHARED_GOLD_V2_BEGIN.*?/\* KCMC_SHARED_GOLD_V2_END \*/','',cssText,flags=re.S)
changes['app-theme.css']=(cssText+'\n'+(HERE/'payload/shared-gold-theme.css').read_text()).encode()
# Cache version literals only. Never modify form, permission or navigation logic.
for candidate in list(ROOT.glob('*.php'))+list(ROOT.glob('*.html'))+[ROOT/'lib/screen-navigation.php']:
 if not candidate.is_file():continue
 rel=str(candidate.relative_to(ROOT))
 current=changes.get(rel,candidate.read_bytes()).decode()
 updated=re.sub(r'app-theme\.css\?v=[A-Za-z0-9._-]+','app-theme.css?v=gold-shared-20261021-v2',current)
 if updated!=current:changes[rel]=updated.encode()

changes['events.php']=re.sub(r'app-theme\.css\?v=[A-Za-z0-9._-]+','app-theme.css?v=gold-shared-20261021-v2',eventsSource).encode()
if 'apply' not in sys.argv:print('CHECK PASSED: Calendar names, times and day popups.');sys.exit(0)
backup=ROOT.parent.parent/('kcmc-calendar-popup-backup-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f'));backup.mkdir(parents=True)
for name in changes:
 dest=backup/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(str(ROOT/name),str(dest))
written=[]
try:
 for name,data in changes.items():
  p=ROOT/name;tmp=p.with_name(p.name+'.popup-tmp');tmp.write_bytes(data);shutil.copymode(str(p),str(tmp));os.replace(str(tmp),str(p));written.append(name)
except Exception:
 for name in written:shutil.copy2(str(backup/name),str(ROOT/name))
 raise
print('SUCCESS: Calendar event names, times and image popups installed. Shared blue-and-gold visual theme updated, including Prayer & Care.')
print('Backup: '+str(backup))
