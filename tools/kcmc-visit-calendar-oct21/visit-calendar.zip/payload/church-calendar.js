'use strict';
(() => {
const $=id=>document.getElementById(id);
const central=new Intl.DateTimeFormat('en-CA',{timeZone:'America/Chicago',year:'numeric',month:'2-digit',day:'2-digit'});
const parts=Object.fromEntries(central.formatToParts(new Date()).map(p=>[p.type,p.value]));
const today=parts.year+'-'+parts.month+'-'+parts.day;
let selected=today,month=new Date(Number(parts.year),Number(parts.month)-1,1),events=[];
const key=d=>[d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-');
function card(e){const box=document.createElement('details');box.className='event';const sum=document.createElement('summary');sum.textContent=e.title;box.append(sum);const p=document.createElement('p');p.textContent=e.body||'Contact the church office for details.';box.append(p);return box;}
function show(){const d=new Date(selected+'T12:00:00');$('selected').textContent=d.toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric',year:'numeric'});const list=events.filter(e=>e.date===selected);$('events').replaceChildren(...list.map(card));if(!list.length){const p=document.createElement('p');p.textContent='No published events for this date.';$('events').append(p);} }
function render(){
$('month').textContent=month.toLocaleDateString('en-US',{month:'long',year:'numeric'});$('days').replaceChildren();
for(const name of ['Sun','Mon','Tue','Wed','Thu','Fri','Sat']){const el=document.createElement('div');el.className='weekday';el.textContent=name;$('days').append(el);}
for(let i=0;i<month.getDay();i++){$('days').append(document.createElement('div'));}
const last=new Date(month.getFullYear(),month.getMonth()+1,0).getDate();
for(let day=1;day<=last;day++){const d=new Date(month.getFullYear(),month.getMonth(),day),k=key(d),n=events.filter(e=>e.date===k).length;const btn=document.createElement('button');btn.type='button';btn.className='day'+(n?' has-events':'')+(k===today?' today':'');btn.setAttribute('aria-pressed',String(k===selected));btn.setAttribute('aria-label',d.toLocaleDateString('en-US',{month:'long',day:'numeric',year:'numeric'})+', '+n+' published events');if(k===today)btn.setAttribute('aria-current','date');const number=document.createElement('span');number.textContent=day;btn.append(number);if(n){const count=document.createElement('span');count.className='count';count.textContent=n+(n===1?' event':' events');btn.append(count);}btn.addEventListener('click',()=>{selected=k;render();show();});$('days').append(btn);}
}
$('prev').addEventListener('click',()=>{month=new Date(month.getFullYear(),month.getMonth()-1,1);selected=key(month);render();show();});
$('next').addEventListener('click',()=>{month=new Date(month.getFullYear(),month.getMonth()+1,1);selected=key(month);render();show();});
$('today').addEventListener('click',()=>{selected=today;month=new Date(today+'T12:00:00');month.setDate(1);render();show();});
fetch('events.php?event_scope=calendar',{cache:'no-store',credentials:'omit'}).then(r=>{if(!r.ok)throw Error();return r.text();}).then(html=>{
const doc=new DOMParser().parseFromString(html,'text/html');const rows=[...doc.querySelectorAll('article.eventx')];if(!doc.querySelector('main#events'))throw Error();events=rows.map(row=>{const c=row.cloneNode(true);const title=c.querySelector('h2')?.textContent.trim()||'Church gathering';const date=c.querySelector('time[datetime]')?.getAttribute('datetime')||'';c.querySelectorAll('summary,img,a,button,script,style').forEach(x=>x.remove());return {title,date:/^\d{4}-\d{2}-\d{2}$/.test(date)?date:'',body:c.textContent.replace(/\n\s*\n/g,'\n').trim()};});
const undated=events.filter(e=>!e.date);$('undated').hidden=!undated.length;$('undatedEvents').replaceChildren(...undated.map(card));$('status').textContent='Published church events loaded. Empty dates have no published events; they do not confirm availability.';$('calendar').hidden=false;render();show();
}).catch(()=>{$('status').replaceChildren(document.createTextNode('The calendar could not load. '));const a=document.createElement('a');a.href='events.php?event_scope=calendar';a.textContent='Open the published event list';$('status').append(a);});
})();
