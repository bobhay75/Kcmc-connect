from pathlib import Path
import re,shutil,datetime,os,json,hashlib,sys
HERE=Path(__file__).resolve().parent
ROOT=Path('/home/bobsome1/public_html/kcmc-connect')
if '--root' in sys.argv:ROOT=Path(sys.argv[sys.argv.index('--root')+1]).resolve()
manifest=json.loads((HERE/'manifest.json').read_text())
for n,h in manifest.items():
 if hashlib.sha256((HERE/'payload'/n).read_bytes()).hexdigest()!=h:raise SystemExit('STOP: package verification failed.')
page=ROOT/('index.php' if (ROOT/'index.php').is_file() else 'index.html')
original=page.read_text();text=original
for n in ['kcmc-kids-safari.jpg','kcmc-building-original-20261018.jpg']:
 if not (ROOT/'assets/visuals'/n).is_file():raise SystemExit('STOP: Missing authentic photo '+n)
a=text.find('<section class="view" data-view="visit">');b=text.find('<section class="view" data-view="watch">',a)
if a<0 or b<0:raise SystemExit('STOP: Visit section not found.')
v=text[a:b]
for title,marker,body in [
 ('Kids at 10:30','data-kcmc-kids-preview','<img data-kcmc-kids-preview src="assets/visuals/kcmc-kids-safari.jpg" alt="Children in the KCMC safari activity cart" loading="lazy" style="display:block;width:100%;max-width:720px;height:auto;border-radius:8px;margin:16px 0;">'),
 ('One easy destination','data-kcmc-map-preview','<a data-kcmc-map-preview href="https://www.google.com/maps/search/?api=1&amp;query=Kimberling+City+Methodist+Church+57+Kimberling+City+Center+Lane+MO" target="_blank" rel="noopener" aria-label="Open KCMC in Google Maps"><img src="assets/visuals/kcmc-building-original-20261018.jpg" alt="Kimberling City Methodist Church — open Google Maps" loading="lazy" style="display:block;width:100%;max-width:720px;height:auto;border-radius:8px;margin:16px 0;"></a><p data-kcmc-map-preview>Tap the church photo to open Google Maps.</p>')]:
 pat=r'(<details\b[^>]*>\s*<summary>\s*<h3>'+re.escape(title)+r'</h3>\s*</summary><div class="disclosure-content">)(.*?)(</div></details>)'
 m=list(re.finditer(pat,v,re.S))
 if len(m)!=1:raise SystemExit('STOP: Expected one '+title+' dropdown.')
 m=m[0];c=m.group(2)
 if marker not in c:c=body+c
 v=v[:m.start()]+m.group(1)+c+m.group(3)+v[m.end():]
text=text[:a]+v+text[b:]
changes={page:text.encode()}
old='kcmc-traditional-sanctuary-20261018.jpg';new='kcmc-traditional-choir-v2.jpg'
# Patch only public presentation sources; do not touch accounts or private records.
candidates=list(ROOT.glob('*.php'))+list(ROOT.glob('*.html'))+list(ROOT.glob('*.js'))+list((ROOT/'lib').glob('*.php'))+[ROOT/'data/content.json']
for p in candidates:
 if not p.is_file():continue
 data=changes.get(p,p.read_bytes())
 if old.encode() in data:changes[p]=data.replace(old.encode(),new.encode())
# Existing Church calendar links lead to the new working month view.
for p in [page,ROOT/'events.php']:
 if not p.is_file():raise SystemExit('STOP: Expected events endpoint missing.')
 s=changes.get(p,p.read_bytes()).decode()
 pat=r'<nav class="btns" aria-label="Event calendar view">.*?</nav>'
 s,count=re.subn(pat,'<nav class="btns" aria-label="Event calendar view"><a class="btn secondary" href="church-calendar.html">Church calendar</a></nav>',s,flags=re.S)
 if count!=1:raise SystemExit('STOP: Expected one Church calendar navigation in '+p.name)
 changes[p]=s.encode()
for n,rel in [('kcmc-traditional-choir-v2.jpg','assets/visuals/kcmc-traditional-choir-v2.jpg'),('church-calendar.html','church-calendar.html'),('church-calendar.js','church-calendar.js')]:changes[ROOT/rel]=(HERE/'payload'/n).read_bytes()
if 'apply' not in sys.argv:print('CHECK PASSED: Traditional replacement, kids photo, Maps photo link and interactive calendar.');sys.exit(0)
backup=Path('/home/bobsome1')/('kcmc-visit-calendar-backup-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
if '--root' in sys.argv:backup=ROOT.parent/backup.name
backup.mkdir(parents=True);record={}
for p in changes:
 rel=str(p.relative_to(ROOT));record[rel]=p.exists()
 if p.exists():
  dest=backup/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(str(p),str(dest))
(backup/'files.json').write_text(json.dumps(record))
written=[]
try:
 for p,data in changes.items():
  p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_name(p.name+'.visit-tmp');tmp.write_bytes(data)
  if p.exists():shutil.copymode(str(p),str(tmp))
  else:tmp.chmod(0o644)
  os.replace(str(tmp),str(p));written.append(p)
except Exception:
 for p in reversed(written):
  rel=str(p.relative_to(ROOT))
  if record[rel]:shutil.copy2(str(backup/rel),str(p))
  elif p.exists():p.unlink()
 raise
print('SUCCESS: Traditional photo replaced; kids and Maps photos added; Church calendar opens interactive month view.')
print('Backup: '+str(backup))
